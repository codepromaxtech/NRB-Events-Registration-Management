<!DOCTYPE html>
<html>
<head>
    <title>Registration Approved</title>
</head>
<body>
    <h1>Congratulations, {{ $registration->name }}!</h1>
    <p>Your registration for the NRB Global Convention has been approved.</p>
    <p>Please find your visiting card attached to this email.</p>
    <br>
    <p>Best regards,</p>
    <p>NRB Global Convention Team</p>
</body>
</html>
